from chainer.serializers import hdf5

HDF5Serializer = hdf5.HDF5Serializer
HDF5Deserializer = hdf5.HDF5Deserializer
save_hdf5 = hdf5.save_hdf5
load_hdf5 = hdf5.load_hdf5

from Predictor import Predictor
from datacleaner import cleanInputData, readCommonVocab, cleanGeneratedData, getDirForAuthor

def lambda_handler(event, context):
   author = event["author"]

   # Load in the predictor
   modelFile = getDirForAuthor(author) + author + ".model"
   vocabFile = getDirForAuthor(author) + author + ".vocab"
   predictor = Predictor(128, model=modelFile, vocab=vocabFile)

   # Clean the user data and separate out unknown words.
   commonVocab = readCommonVocab(getDirForAuthor(author) + author + ".commons")
   data, uniqueUserWords = cleanInputData(event["userText"], commonVocab)
   prime_sequence = data[-5:]

   generatedSample = predictor.sample(event["length"], prime_sequence);
   return cleanGeneratedData(' '.join(generatedSample), uniqueUserWords)
